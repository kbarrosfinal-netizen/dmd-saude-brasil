# 📦 Pacote de Upload Manual — Release v2.2 DMD Canônica
**Repositório:** https://github.com/kbarrosfinal-netizen/dmd-saude-brasil  
**Data de geração:** 23/03/2026  
**Status da base:** ✅ ÍNTEGRA — 104/104 verificações aprovadas

---

## 📁 Estrutura deste pacote

```
dmd_release_v2_2_upload/
├── INSTRUCOES_UPLOAD_GITHUB.md          ← este arquivo
│
├── .github/
│   └── workflows/
│       └── publish-release-v2-2.yml    ← Workflow GitHub Actions (upload manual 1x)
│
└── releases/
    └── dmd-canonica-v2-2/
        ├── README.md                               (5 KB)   ← nota técnica da release
        ├── dmd_resumo_v2_2.json                    (1 KB)   ← métricas consolidadas
        ├── dmd_base_uf_canonica_v2_2.csv           (1 KB)   ← resumo por UF
        ├── dmd_aliases_materializados_12_v2_2.csv  (3 KB)   ← 12 aliases validados
        ├── dmd_pendencias_remanescentes_28_v2_2.csv (7 KB)  ← 28 pendências manuais
        ├── dmd_proposta_decisao_manual_29_casos_v2_2.csv (7 KB)
        ├── dmd_validacao_41_pendencias_v2_2.csv    (11 KB)  ← validação completa
        ├── dmd_base_municipal_canonica_v2_2.csv    (4.1 MB) ← BASE PRINCIPAL
        └── dmd_base_canonica_integrada_v2_2.xlsx   (2.9 MB) ← EXCEL INTEGRADO
```

---

## 🚀 Passo a Passo — Upload via Interface GitHub

### PASSO 1 — Fazer upload do Workflow (habilita publicação automática futura)

1. Acesse: https://github.com/kbarrosfinal-netizen/dmd-saude-brasil
2. Navegue até `.github/workflows/`
3. Clique em **"Add file" → "Upload files"**
4. Arraste o arquivo: `.github/workflows/publish-release-v2-2.yml`
5. Mensagem do commit: `ci: add workflow to publish release v2.2`
6. Clique em **"Commit changes"**

> ✅ Após este passo, o workflow fica disponível em: Actions → "Publicar Release v2.2"

---

### PASSO 2 — Criar a pasta da release e fazer upload dos arquivos

1. Acesse: https://github.com/kbarrosfinal-netizen/dmd-saude-brasil
2. Clique em **"Add file" → "Upload files"**
3. **IMPORTANTE:** No campo de destino, você precisará criar a pasta.  
   Use o botão de upload e, quando pedir o nome do arquivo, escreva:  
   `releases/dmd-canonica-v2-2/README.md` (o GitHub cria a pasta automaticamente)

**Sequência recomendada de upload** (dos menores para os maiores):

| Ordem | Arquivo | Tamanho |
|-------|---------|---------|
| 1 | `releases/dmd-canonica-v2-2/README.md` | 5 KB |
| 2 | `releases/dmd-canonica-v2-2/dmd_resumo_v2_2.json` | 1 KB |
| 3 | `releases/dmd-canonica-v2-2/dmd_base_uf_canonica_v2_2.csv` | 1 KB |
| 4 | `releases/dmd-canonica-v2-2/dmd_aliases_materializados_12_v2_2.csv` | 3 KB |
| 5 | `releases/dmd-canonica-v2-2/dmd_pendencias_remanescentes_28_v2_2.csv` | 7 KB |
| 6 | `releases/dmd-canonica-v2-2/dmd_proposta_decisao_manual_29_casos_v2_2.csv` | 7 KB |
| 7 | `releases/dmd-canonica-v2-2/dmd_validacao_41_pendencias_v2_2.csv` | 11 KB |
| 8 | `releases/dmd-canonica-v2-2/dmd_base_municipal_canonica_v2_2.csv` | **4.1 MB** |
| 9 | `releases/dmd-canonica-v2-2/dmd_base_canonica_integrada_v2_2.xlsx` | **2.9 MB** |

> 💡 **Dica:** Você pode selecionar todos os arquivos de uma vez no uploader do GitHub  
> (exceto o README que vai primeiro para criar a pasta).

---

### PASSO 3 — Verificar resultado

Após o upload, acesse:  
🔗 https://github.com/kbarrosfinal-netizen/dmd-saude-brasil/tree/main/releases/dmd-canonica-v2-2

Você deve ver os 9 arquivos listados.

---

## 📊 Métricas da Base v2.2

| Indicador | Valor |
|-----------|-------|
| Municípios oficiais | **5.570** |
| IBGEs únicos | **5.570** |
| Duplicatas | **0** |
| Mapeados alta confiança | **5.529** |
| Homologados manual | **1** (São Bento do Una/PE) |
| Sem correspondência segura | **40** |
| Aliases materializados | **12** |
| Critério gerencial | **5.541** |
| Colunas por município | **121** |
| Verificações de integridade | **104/104 ✅** |

---

## 🔑 Informações Técnicas

- **Commit da release:** `9db4fdd` — feat: publica baseline operacional v2.2  
- **Commit do workflow:** `0f43256` — ci: add workflow publish release v2.2  
- **Branch:** `main`  
- **Gerado por:** Genspark AI — EMET DMD GESTÃO BRASIL Hub  
